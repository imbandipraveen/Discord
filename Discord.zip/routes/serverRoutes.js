const express = require('express');
const router = express.Router();
const { 
  createServer, 
  getServerInfo,
  addNewChannel,
  addNewCategory,
  deleteServer,
  leaveServer 
} = require('../controllers/serverController');
const { authToken } = require('../middleware/auth');

router.use(authToken);

router.post('/create', createServer);
router.post('/info', getServerInfo);
router.post('/channel/new', addNewChannel);
router.post('/category/new', addNewCategory);
router.post('/delete', deleteServer);
router.post('/leave', leaveServer);

module.exports = router; 