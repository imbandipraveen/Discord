const { Server } = require('socket.io');

const setupSocket = (server) => {
  const io = new Server(server, {
    pingTimeout: 20000,
    cors: {
      origin: "https://project-discord.netlify.app",
    },
  });

  io.on('connection', (socket) => {
    socket.on('get_userid', (user_id) => {
      socket.join(user_id);
    });

    socket.on('send_req', (receiver_id, sender_id, sender_profile_pic, sender_name) => {
      socket.to(receiver_id).emit('recieve_req', {
        sender_name,
        sender_profile_pic,
        sender_id,
      });
    });

    // ... other socket events
  });

  return io;
};

module.exports = { setupSocket }; 