/// <reference types='cypress'/>
import { createUniqueTestUser } from "./utils/registration.utils";
import { registrationPage } from "./page-objects/registration.page";

describe("User Registration Tests", () => {
  let testData;

  before(() => {
    cy.fixture("registration-data").then((data) => {
      testData = data;
    });
  });

  beforeEach(() => {
    registrationPage.visit();
  });

  describe("Form Validation", () => {
    it("should validate empty form submission", () => {
      registrationPage.submitForm();
      registrationPage.verifySubmitButtonState(false);
    });

    it("should validate required fields one by one", () => {
      // Test with email only
      cy.fillRegistrationForm({ email: testData.validUser.email });
      registrationPage.submitForm();
      registrationPage.verifySubmitButtonState(false);

      // Test with email and username
      cy.fillRegistrationForm({
        email: testData.validUser.email,
        username: testData.validUser.username,
      });
      registrationPage.submitForm();
      registrationPage.verifySubmitButtonState(false);

      // Test with complete data
      cy.fillRegistrationForm(testData.validUser);
      registrationPage.submitForm();
      registrationPage.verifySubmitButtonState(true);
    });
  });

  describe("Error Handling", () => {
    it("should handle existing email error correctly", () => {
      cy.fillRegistrationForm(testData.existingUser);
      registrationPage.submitForm();

      registrationPage.verifyAlertMessage(testData.errorMessages.emailExists);
      registrationPage.closeAlert();
    });
  });

  describe("Successful Registration", () => {
    it("should complete registration with valid data", () => {
      const newUser = createUniqueTestUser(testData.validUser);

      cy.fillRegistrationForm(newUser);
      registrationPage.submitForm();

      registrationPage.verifySuccessfulRegistration();
    });
  });
});
